#!/bin/bash

for j in {1..100};
	do
		for i in {1..100};
		do 
			php test.php &
		done
		wait
	done
wait
