<?php
require_once 'rb-postgres.php';

$user = 'postgres';
$password = '123';
$dsn =  sprintf('pgsql:host=localhost;dbname=console_test;user=%s;password=%s;port=6432', $user, $password);
//$dsn =  sprintf('pgsql:host=localhost;dbname=jorge;user=%s;password=%s;', $user, $password);
R::setup($dsn);

for ($i = 0; $i < 100; $i++) {
    $sql = "INSERT INTO playground(type, color, location, install_date) values(:type, :color, :location, :install_date)";
    $params = [
        ':type' => "type1",
        ':color' => "color",
        ':location' => "north",
        ':install_date' => "now()",
    ];
    R::exec($sql, $params);
}
R::close();
